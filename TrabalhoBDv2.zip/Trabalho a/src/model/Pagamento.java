package model;

public class Pagamento {
    
    private int id;
    private double valor;
    private int clienteId;

    public Pagamento(double valor, int clienteId) {
        this.valor = valor;
        this.clienteId = clienteId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public int getClienteId() {
        return clienteId;
    }

    public void setClienteId(int clienteId) {
        this.clienteId = clienteId;
    }


}
