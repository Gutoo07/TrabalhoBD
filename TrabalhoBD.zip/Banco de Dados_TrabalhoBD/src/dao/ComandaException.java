package dao;

public class ComandaException extends Exception {
    public ComandaException(Throwable th) {
        super(th);
    }
}
